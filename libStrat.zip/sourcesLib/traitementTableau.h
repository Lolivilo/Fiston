#ifndef _traitementTableau_h
#define _traitementTableau_h

#include "strategy.h"


/** Fonctions relatives aux traitements de tableaux
**/

int FindMaxPriority(Strat_move* tab, int length);
int FindMaxPriority2(Strat_move* tab, int length);
#endif
